#include "status-tab.hpp"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGroupBox>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

namespace {

QString statusText(bool live, int viewers)
{
	if (!live)
		return QObject::tr("Offline");
	if (viewers < 0)
		return QObject::tr("Live");
	return QObject::tr("Live \u00b7 %1 viewers").arg(viewers);
}

QGroupBox *buildSection(QWidget *parent, const QString &name, QLabel *&status,
			QLineEdit *&title, QPushButton *&btn)
{
	auto *box = new QGroupBox(name, parent);
	auto *v = new QVBoxLayout(box);

	status = new QLabel(QObject::tr("Offline"), box);
	status->setStyleSheet(QStringLiteral("font-weight: bold;"));
	v->addWidget(status);

	auto *row = new QHBoxLayout();
	title = new QLineEdit(box);
	title->setPlaceholderText(QObject::tr("Stream title"));
	btn = new QPushButton(QObject::tr("Update title"), box);
	row->addWidget(title, 1);
	row->addWidget(btn);
	v->addLayout(row);

	return box;
}

} // namespace

StatusTab::StatusTab(QWidget *parent) : QWidget(parent)
{
	auto *layout = new QVBoxLayout(this);
	layout->setContentsMargins(8, 8, 8, 8);
	layout->setSpacing(8);

	QPushButton *ytBtn = nullptr;
	QPushButton *twBtn = nullptr;

	layout->addWidget(buildSection(this, tr("YouTube"), m_ytStatus,
				       m_ytTitle, ytBtn));
	layout->addWidget(buildSection(this, tr("Twitch"), m_twStatus,
				       m_twTitle, twBtn));
	layout->addStretch(1);

	connect(ytBtn, &QPushButton::clicked, this, [this]() {
		emit youtubeTitleSubmitted(m_ytTitle->text().trimmed());
	});
	connect(twBtn, &QPushButton::clicked, this, [this]() {
		emit twitchTitleSubmitted(m_twTitle->text().trimmed());
	});
}

void StatusTab::setYouTubeInfo(bool live, int viewers, const QString &title)
{
	m_ytStatus->setText(statusText(live, viewers));
	// Don't overwrite the field while the user is editing it.
	if (!m_ytTitle->hasFocus() && !title.isEmpty())
		m_ytTitle->setText(title);
}

void StatusTab::setTwitchInfo(bool live, int viewers, const QString &title)
{
	m_twStatus->setText(statusText(live, viewers));
	if (!m_twTitle->hasFocus() && !title.isEmpty())
		m_twTitle->setText(title);
}
