#pragma once

#include <QWidget>

class QLabel;
class QLineEdit;

// "Status" dock: shows live status + concurrent viewers per platform and lets
// the user edit the stream title. YouTube section on top, Twitch below.
class StatusTab : public QWidget {
	Q_OBJECT
public:
	explicit StatusTab(QWidget *parent = nullptr);

	void setYouTubeInfo(bool live, int viewers, const QString &title);
	void setTwitchInfo(bool live, int viewers, const QString &title);

signals:
	void youtubeTitleSubmitted(const QString &title);
	void twitchTitleSubmitted(const QString &title);

private:
	QLabel *m_ytStatus = nullptr;
	QLineEdit *m_ytTitle = nullptr;
	QLabel *m_twStatus = nullptr;
	QLineEdit *m_twTitle = nullptr;
};
